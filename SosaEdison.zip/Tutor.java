
/**
 * The Tutor was a gift to the player
 * as to make the game a bit easier. 
 * Tutors can diable trap but it costs
 * them their lives.
 * 
 * @author Sosa Edison-Edebor
 *
 */
public class Tutor extends Mobile {

	/**
	 * Tells the tutor to take a break
	 */
	private final long BREAK = 1000;
	
	/**
	 * Constructor for the Tutor and it take a board to 
	 * tutor on. 
	 * @param board The board for the tutor to move on
	 */
	public Tutor(Board board) {
		super(board);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Can the tutor be seen and open cells
	 * @return Yes then can be seen
	 */
	@Override
	public boolean isVisible() {
		// TODO Auto-generated method stub
		return true;
	}

	/**
	 * Who can the tutor share a cell with
	 * @return Whether or not the tutor can share that cell
	 * @param THe element that wants to share
	 */
	@Override
	public boolean share(Boardable elem) {
		if(elem instanceof HomeworkTrap) {
			this.board.removeElement(elem);
			this.board.removeElement(this);
			return false;
		}
		return false;
	}

	/**
	 * Runs the Tutor
	 */
	@Override
	public void run() {
		
		while(true) {
			this.move();
			try {
				Thread.sleep(BREAK);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	/**
	 * String representation of the tutor
	 * @return What the tutor looks like
	 */
	public String toString() {
		return "T";
	}

}
