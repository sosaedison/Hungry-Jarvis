import java.util.ArrayList;
import java.util.Random;

/**
 * This instance of jarvis terrorizes the 
 * board by spawning traps every 4 moves
 * and needs to be hugged by the player
 * @author Sosa Edison-Edebor
 *
 */
public class Jarvis extends Mobile {
	/**
	 * ArrayList to hold the moves for Jarvis 
	 */
	ArrayList<Direction> moves;
	/**
	 * Used to pull a random move from the moves ArrayList
	 */
	Random rand;
	/**
	 * Holds the the rest time for Jarvis before he can move again. 
	 */
	protected final long TIRED = 250;

	/**
	 * Constructor for Jarvis that needs a board
	 * then creates a arraylist of moves and a random
	 * instance as well
	 * @param board The board for this instance of the Jarvis
	 */
	public Jarvis(Board board) {
		super(board);
		moves = new ArrayList<Direction>();
		rand  = new Random();
		
	}

	/**
	 * Lays a trap in a cell. TO make the 
	 * game easier, jarvis can't lay trap
	 * if placeElement return false and jarvis then
	 * moves to a new cell and tries again.
	 * The game is still pretty hard.
	 */
	public void layTrap() {
		HomeworkTrap trap;
		int randIndex;
		Direction newDir;
		int row = this.board.getRow(this);
		int col = this.board.getCol(this);
		int nextRow = row;
		int nextCol = col;
	
		randIndex = rand.nextInt(8);
		trap = new HomeworkTrap(this.board);
		newDir = super.moves.get(randIndex);
		
		if(newDir == Direction.DOWN) {
			nextRow++;
		}else if(newDir == Direction.DOWN_LEFT) {
			nextRow++;
			nextCol--;
		}else if(newDir == Direction.DOWN_RIGHT) {
			nextRow++;
			nextCol++;
		}else if(newDir == Direction.LEFT) {
			nextCol--;
		}else if(newDir == Direction.RIGHT) {
			nextCol++;
		}else if(newDir == Direction.UP) {
			nextRow--;
		}else if(newDir == Direction.UP_LEFT) {
			nextRow--;
			nextCol--;
		}else if(newDir == Direction.UP_RIGHT) {
			nextRow--;
			nextCol++;
		}
		this.board.placeElement(trap, nextRow, nextCol);
		
	}
	
	
	/**
	 * Runs the jarvis thread
	 */
	public void run() {
		int counter = 1;
		while(!this.board.beenHugged()) {
			
			this.move();
			if(counter%4 == 0) { // every 4 moves, places a trap
				this.layTrap();
			}
			counter++;
			try {
				Thread.sleep(TIRED); // rests for a .25 secs
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Jarvis Has been hugged");
		return;

	}
	
	/**
	 * Checks to see what jarvis can and cannot share a cell with and 
	 * what should happen in the given cases below.
	 * 
	 * @return Whether or not jarvis could share a cell with that object
	 */
	public boolean share(Boardable elem) {
		if(!(elem instanceof Mobile)) {
			return false;
		}
		
		if(elem instanceof Tutor) {
			this.board.removeElement(elem);
			return false;
		}
		this.board.setHugged(true);
		return true;
	}

	/**
	 * Whether or not Jarvis can be seen by the Player.
	 * @return The player can't see him unless he is in an open cell.
	 */
	@Override
	public boolean isVisible() {
		return false;
	}
	
	/**
	 * String representation of jarvis
	 * @return how the player sees him
	 */
	public String toString() {
		return "?";
	}
	
	
}
