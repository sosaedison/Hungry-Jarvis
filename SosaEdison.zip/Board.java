import java.util.ArrayList;
import java.util.HashMap;

/**
 * The board class is responsible for displaying the board as it is.
 * Board creates a 2-D array of cells. Board elements can be placed
 * in a particular cell. After an element has been placed, the Board
 * is responsible for tracking its location.
 * 
 * @author Sosa Edison-Edebor
 *
 */
public class Board {


	/**
	 * New 2-D array of cells.
	 */
	private Cell[][] board;
	
	/**
	 * This holds the height of the board.
	 * The number of rows.
	 */
	private int hieght;
	
	/**
	 * This holds the width of the board.
	 * The number of columns.
	 */
	private int width;
	
	/**
	 * Maps elements that can be on the board to a cell on the board
	 */
	HashMap<Boardable, Cell> elementPlace;
	
	/**
	 * Boolean that holds the state of Jarvis and whether he has been hugged
	 */
	private boolean hugged;
	
	/**
	 * Constructor for Board that takes a height
	 * and width. The hashmap is created as well
	 * as the board 2-d cell array. the board is also filled
	 * 
	 * @param height // how many rows for the board
	 * @param width // how many columns for the board
	 */
	public Board(int height, int width)
	{
		this.hieght = height;
		this.width  = width;
		if(this.hieght > 100 || this.hieght < 0 || this.width > 100 || this.width < 0) {
			throw new IllegalArgumentException ("Sorry, those were incorrect dimensions!");
		}
		hugged = false;
		elementPlace = new HashMap<Boardable, Cell>();
		board = new Cell[this.hieght][this.width];
		
		fillBoard(); // board is filled with cells
	}
	
	/**
	 * This method take a direction from the a Boardable element, and
	 * calculates the appropriate cell to place the 
	 * element in. The coordinates are sent to the 
	 * placeElement method to handle if that 
	 * cell exists.
	 * 
	 * @param dir // Direction from the enum
	 * @param elem // Passed instance of Stylus
	 * @return // true if there was a move made
	 */
	synchronized public boolean move(Direction dir, Boardable elem)
	{
		if(!elementPlace.containsKey(elem)) {
			throw new IllegalArgumentException ("This element is not on the board!"); 
		}
		
		Cell curC = elementPlace.get(elem);
		
		int row = curC.getRow();
		int col = curC.getCol();
		
		/**
		 * Series of if-else checks
		 * to appropriately move the
		 * element around the board
		 */
		if(dir == Direction.DOWN)
		{
			row++;
		}else if(dir == Direction.DOWN_LEFT)
		{
			row++;
			col--;
		}else if(dir == Direction.DOWN_RIGHT)
		{
			row++;
			col++;
		}else if(dir == Direction.LEFT)
		{
			col--;
		}else if(dir == Direction.RIGHT)
		{
			col++;
		}else if(dir == Direction.UP)
		{
			row--;
		}else if(dir == Direction.UP_LEFT)
		{
			row--;
			col--;
		}else if(dir == Direction.UP_RIGHT)
		{
			row--;
			col++;
		}
		
		if(row < 0 || row > this.hieght-1 || col < 0 || col > this.width-1) {
			return false;
		}

		placeElement(elem, row, col);
		return true;
	}
	
	/**
	 * This method places the passed in element in the cell calculated from the 
	 * move method. As well as in the element hashmap that 
	 * 
	 * @param elem // A Player or Jarvis or HomeworkTrap
	 * @param row // the new row
	 * @param col // the new column
	 * @return // whether or not the move could have been made
	 */
	synchronized public boolean placeElement(Boardable elem, int row, int col)
	{
		Cell tempCell;
		
		// Were valid coordinate passed in?
		if(row < 0 || row > this.hieght-1 || col < 0 || col > this.width-1) {
			return false;
		}
		
		// For placing the player and jarvis
		while(elementPlace.size() < 2) {
			tempCell = board[row][col];
			tempCell.addElement(elem);
			elementPlace.put(elem, tempCell);
			
			return true;
		}
		
		// For the first Tutor to be placed
		if(elem instanceof Tutor && !elementPlace.containsKey(elem)) {
			tempCell = board[row][col];
			if(tempCell.addElement(elem)) {
				elementPlace.put(elem, tempCell);
				return true;
			}
			return false;
		}
		
		// For placing all the traps
		if(elem instanceof HomeworkTrap ) {
			tempCell = board[row][col];
			tempCell.addElement(elem);
			elementPlace.put(elem, tempCell);
			return true;
		}
		
		// Movement for all mobile elements 
		tempCell = elementPlace.get(elem);
		tempCell.removeElement(elem);

		tempCell = board[row][col];
		tempCell.addElement(elem);
		elementPlace.put(elem, tempCell);
		return true;
	}
	
	/**
	 * Prints the board based on entered dimensions, row by row.
	 */
	synchronized public void printBoard()
	{
		for(int row = 0; row < this.hieght; row++)
		{
			for(int col = 0; col < this.width; col++)
			{
				System.out.print(board[row][col].toString());
			}
			System.out.println("");
		}
	}
	
	/**
	 * Returns where the passed in element is, 
	 * in terms of rows.
	 * 
	 * @param elem The element we want the row coordinate of
	 * @return The Row coordinate
	 */
	public int getRow(Boardable elem) {
		return elementPlace.get(elem).getRow();
		
	}
	/**
	 * Returns where the passed in element is, 
	 * in terms of columns.
	 * 
	 * @param elem The element we want the column coordinate of
	 * @return The Column coordinate
	 */
	public int getCol(Boardable elem) {
		return elementPlace.get(elem).getCol();
	}
	
	
	/**
	 * Tells the user that Jarvis has been hugged
	 * and sets the hugged boolean to true, which ends the player
	 * and jarvis threads.
	 * @param hugged Whether or not Jarvis has been hugged
	 */
	public void setHugged(boolean hugged) {
		hugged = !hugged;
		System.out.println("Looks like Jarvis has been hugged\n" + "He is now calm!");
	}
	
	/**
	 * Whether or not Jarvis has been hugged.
	 * @return The value of hugged
	 */
	public boolean beenHugged() {
		return hugged;
		
	}
	
	/**
	 * Removes the passed in element from the board
	 * and from the elementPlace HashMap
	 * 
	 * @param elem The element we want to remove
	 * @return True if could be removed, false otherwise
	 */
	synchronized public boolean removeElement(Boardable elem) {
		Cell curCell;
		
		if(!elementPlace.containsKey(elem)) {
			throw new IllegalArgumentException (" Not an element in the board!");
		}
			curCell = elementPlace.get(elem);
			elementPlace.remove(elem);
			curCell.removeElement(elem);
			return true;
	}
	
	/**
	 * Fills this instance of a board with
	 * cells in a 2-dimensional array.
	 */
	private void fillBoard()
	{
		for(int row = 0; row < this.hieght; row++) 
		{
			for(int col = 0; col < this.width; col++)
			{
				Cell tempCell = new Cell(row, col);
				board[row][col] = tempCell;
			}
		}
	}

	
	
	/**
	 * The instances of this class are what 
	 * make up the board. Every instance of
	 * cell can hold an element. Every cell
	 * is created without visibility and 
	 * thus is seen as a hashtag. Once the
	 * element has been through a cell, that
	 * cell will be seen as an empty space.
	 * 
	 * @author Sosa Edison-Edebor
	 *
	 */
	private class Cell {
		
		/**
		 * The row of the cell
		 */
		private int row;
		/**
		 * The column of the cell
		 */
		private int col;
		/**
		 * If the cell is visible
		 */
		private boolean isVisible;
		/**
		 * The arraylist that holds the elements
		 */
		private ArrayList<Boardable> elements;
		
		/**
		 * 
		 */
		private final int CAUGHT = 5000;
		/**
		 * Constructor for the cell that needs 
		 * a row and column integer. The visbility
		 * of the cell is instantiated as false
		 * and an array to hold the stylus for the cell
		 * 
		 * @param row // the row the cell is in
		 * @param col // the column the cell is in 
		 */
		public Cell(int row, int col)
		{
			this.row = row;
			this.col = col;
			this.isVisible = false;
			elements = new ArrayList<Boardable>();
		}
		
		/**
		 * Adds the element to the cell and changes its
		 * visibility only if the element was visible
		 * when it was placed in this cell
		 * 
		 * @param elem // the element being added
		 */
		public boolean addElement(Boardable elem)
		{
			if(elements.size() != 0) {
				if(elements.get(elements.size()-1).share(elem)) {
					elements.add(elem);
					return true;
				}
				return false;
			}
			elements.add(elem);
			if(elem.isVisible())
			{
				this.isVisible = true;
			}
			return true;
		}
		
		/**
		 * Removes the element from the cell
		 * 
		 * @param elem // the stylus
		 * @return // it's been removed 
		 */
		public boolean removeElement(Boardable elem)
		{
			elements.remove(elem);
			return true;
		}
		
		/**
		 * Returns the row position of the cell
		 * @return // the row of this cell
		 */
		public int getRow()
		{
			return this.row;
		}
		
		/**
		 * Returns the column position of cell
		 * @return // the column of this cell
		 */
		public int getCol()
		{
			return this.col;
		}
		
		/**
		 * If the cell has a visible element,
		 * this toString will print a string 
		 * representation of what is in it.
		 * 
		 * @return // String representation of the this cell
		 */
		public String toString()
		{
			if(this.isVisible) {
				if(elements.size() != 0) {
					if(!(elements.get(elements.size()-1).isVisible())) {
						return " ";
					} else {
						return elements.get(elements.size()-1).toString();
					}
				}
				return " ";
			}
			return "#";
		}
	}
}
