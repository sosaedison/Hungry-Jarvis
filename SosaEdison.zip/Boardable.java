
public interface Boardable {

	public boolean isVisible();
	
	public boolean share(Boardable elem);
	
	public String toString();
}
