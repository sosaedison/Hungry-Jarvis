import java.util.Scanner;

/**
 * This dirver class runs the game.
 * Asks for user input to create the board. 
 * 
 * @author Sosa Edison-Edebor
 *
 */
public class Game {

	public static void main(String[] args) {
		int row;
		int col;
		Scanner input;
		
		
		input = new Scanner(System.in);
		
		// Get demensions for the board
		System.out.println("Enter a row dimension:");
		row = input.nextInt();
		input.nextLine();
		
		System.out.println("Enter a col dimension:");
		col = input.nextInt();
		input.nextLine();
		
		// create a valid board
		Board board = new Board(row,col);
		Jarvis hungryJarvis = new Jarvis(board);
		Player p1 = new Player(board);
		int jarvisRow;
		int jarvisCol;
		
		// find where to place the jarvis and the player
		jarvisRow = (int)(Math.random()*(row-(row/2)))+row/2;
		jarvisCol = (int)(Math.random()*(col-(col/2)))+col/2;
		board.placeElement(hungryJarvis, jarvisRow, jarvisCol);
		board.placeElement(p1, 0, 0);
		board.printBoard();
		
		// create new threads for the player and jarvis
		Thread player = new Thread(p1);
		Thread hungry = new Thread(hungryJarvis);
		
		// Start the new threads
		player.start();
		hungry.start();
	}

}
