/**
 * This is the only Jarvis can set
 * and it puts the player to sleep
 * so they can do homework for 
 * 5 secs.
 * 
 * @author Sosa Edison-Edebor
 *
 */
public class HomeworkTrap implements Boardable {

	
	/**
	 * An instance of board for the trap to remove itself from. 
	 */
	private Board board;
	
	/**
	 * Holds how long the player should be set to sleep. 
	 */
	private final long CAUGHT = 5000;
	
	/**
	 * This is an instance of the only 
	 * trap Jarvis can set. If the player
	 * comes into contact with a trap, that 
	 * trap will put the player to sleep for 
	 * 5 seconds. 
	 * 
	 * @param board The board that it will be placed on
	 */
	public HomeworkTrap(Board board) {
		this.board = board;
	}
	
	/**
	 * This method checks to see what wants to share a cell
	 * with a homework trap. 
	 * @param The element that wants to share a cell with the homework trap
	 * @return False if it's a trap or player | True if it's Jarvis
	 */
	public boolean share(Boardable elem) {
		
		if(!(elem instanceof Mobile)) {
			return false;
		}
	
		if(elem instanceof Jarvis){
			return true;
		}

		if(elem instanceof Player) {
			Player tempPlayer = (Player) elem;
			tempPlayer.setDelay(CAUGHT);
			this.board.removeElement(this);
			return true;
		}
		return false;
	}

	/**
	 * If the trap is visible to the user. 
	 * 
	 * @return Whether or not the trap can be seen
	 */
	@Override
	public boolean isVisible() {
		return false;
	}
	
	/**
	 * A string representation of the trap
	 * @return Nothing because than the user can't seen them
	 */
	public String toString() {	
		return " ";
	}
}
