import java.util.ArrayList;
import java.util.Random;

/**
 * Mobile abstract class is used for 
 * all the mobile things on the board
 * 
 * @author CHIEF
 *
 */
public abstract class Mobile implements Runnable, Boardable {
	
	/**
	 * Board to move on 
	 */
	protected Board board;
	/**
	 * New random for the move selection
	 */
	protected Random rand = new Random();
	/**
	 * Moves for the element to pick from
	 */
	protected ArrayList<Direction> moves = new ArrayList<Direction>();
	
	/**
	 * Constructor for a boardable element 
	 * of type mobile and all it needs is
	 * a board to move on.
	 * 
	 * @param board The board to move on
	 */
	public Mobile(Board board) {
		this.board = board;
		fillMoves();
	}
	
	/**
	 * Move method of the Jarvis and Tutor
	 * since they move autonomously.
	 * Looks for a valid move until it's found.
	 */
	protected void move() {
		int randIndex;
		boolean looking = true;
		Direction newDir;
				
		while(looking) {
			
			randIndex = rand.nextInt(8);
			newDir = moves.get(randIndex);

			for(Direction tempDir : moves) {
				if(newDir == tempDir) {
					if(this.board.move(newDir, this)) // if the move wasn't out of bounds
					{
						looking  = false; // jump out of the loop
					}
				}
			}
		}
	}
	
	/**
	 * Moves for the moving elements
	 */
	private void fillMoves() {
		for(int i = 0; i < Direction.values().length; i++) {
			moves.add(Direction.values()[i]);
		}
	}
			
}
