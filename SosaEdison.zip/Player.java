import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

/**
 * The Player class is the user's way on interacting 
 * with the Board. The goal is for the Player to 
 * hug jarvis and settle is anger. 
 * 
 * @author Sosa Edison-Edebor
 *
 */
public class Player extends Mobile {
	/**
	 * Scanner for user input
	 */
	private Scanner input;
	/**
	 * Possible inputs from the user
	 */
	private char[] possibleMoves = {'q','w','e','a','d','z','x','c'};
	/**
	 * New hashmap the maps the moves keys to the moves on the board
	 */
	private HashMap<Character, Direction> moves;
	
	/**
	 * Holds the delay time for the player
	 */
	private long delayTime;
	
	/**
	 * Used to check if the player wants to stay still and just see the board
	 */
	private String CHILL = "s";
	
	/**
	 * Constructor for the player instance. Needs a board,
	 * creates a list of moves for the player, initializes the 
	 * scanner and hashmap for charcter entries and moves 
	 * availible on the board.
	 * 
	 * @param board The board the player will play on
	 */
	public Player(Board board) {
		super(board);
		input = new Scanner(System.in);
		moves = new HashMap<Character, Direction>();
		movesList();
	}
	
	/**
	 * Moves the player around the board.
	 * Asks for new move it there a wall in
	 * the way. 
	 */
	synchronized protected void move()
	{
		String move;
		
		System.out.print("Move:");
		move = input.nextLine();
		
		if(validMove(move)) // checks to see if what the user entered was a valid move
		{
			if(this.board.move(moves.get(move.charAt(0)), this)) // moves the player in this direction
			{
				this.board.printBoard(); // prints the board
			}else if (move.equals(CHILL)) {
				this.board.printBoard();
				System.out.println("Staying put!");
			}else {
				this.board.printBoard();
			}
		}
	}


	/**
	 * Runs the Player thread
	 */
	public void run() {
		int counter = 1;
		while(!this.board.beenHugged()) {
			delay();
			move();
			
			if(counter%8 == 0) { // every 8 moves, lays a tutor
				layTutor();
			}
			counter++;
		}
	}
	
	/**
	 * Tries to delay the player only if there is
	 * a delay time.
	 * @param time The time the Player has to wait this turn
	 */
	private void delay() {
		try {

			Thread.sleep(delayTime);
			while(System.in.available() > 0) {
				System.in.read();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		delayTime = 0;
	}
	
	/**
	 * Sets the delay time for the player 
	 * if the player hits a trap. The user 
	 * is notified of such happenings. 
	 * @param time An amount of time for the player to wait. 
	 */
	public void setDelay(long time) {
		delayTime = time;
		System.out.println("Oh no! The player has hit a trap!");
		System.out.println("Doing Homework now...");
	}
	
	/**
	 * 
	 * @return Player can't share with anything 
	 */
	public boolean share (Boardable elem) {
		return false;
	}
	
	/**
	 *If the player can be seen by the user
	 * @return Yes the player can be seen by the user
	 */
	@Override
	public boolean isVisible() {
		return true;
	}
	
	/**
	 * What the player looks like to the user
	 * 
	 * @return The astrisk 
	 */
	public String toString() {
		return "*";
	}
	
	/**
	 * Method that takes the move from the user,
	 * converts the char's in the possibleMoves 
	 * array and returns true if there is a match
	 * between them.
	 * 
	 * @param input // a move from the user
	 * @return // whether or not that moves exists
	 */
	private boolean validMove(String move) {
		for(char c: possibleMoves) // Loop through the move
		{
			if(move.equals(Character.toString(c)))
			{
				return true;
			}
		}
		return false;
	}
	/**
	 * Method that puts char keys in the hashmap
	 * with Direction values.
	 */
	private void movesList()
	{
		int index = 0;
		for(Direction dir : Direction.values())
		{
			moves.put(possibleMoves[index], dir);
			index++;
		}
	}
	
	/**
	 * Method that lays the tutor down
	 * and starts the thread for that 
	 * instance of the tutor every
	 * 8 moves from the player. Keeps 
	 * trying to place a tutor if the player
	 * is trapped by a wall. 
	 */
	private void layTutor() {
		
		int row = this.board.getRow(this);
		int col = this.board.getCol(this);
		Tutor newTutor;
		boolean placing  = true;
		
		while(placing) {
			newTutor = new Tutor(this.board);
			int randIndex = rand.nextInt(8);
			Direction newDir = super.moves.get(randIndex);
			int nextRow = row;
			int nextCol = col;
			
			if(newDir == Direction.DOWN) {
				nextRow++;
			}else if(newDir == Direction.DOWN_LEFT) {
				nextRow++;
				nextCol--;
			}else if(newDir == Direction.DOWN_RIGHT) {
				nextRow++;
				nextCol++;
			}else if(newDir == Direction.LEFT) {
				nextCol--;
			}else if(newDir == Direction.RIGHT) {
				nextCol++;
			}else if(newDir == Direction.UP) {
				nextRow--;
			}else if(newDir == Direction.UP_LEFT) {
				nextRow--;
				nextCol--;
			}else if(newDir == Direction.UP_RIGHT) {
				nextRow--;
				nextCol++;
			}
			if(this.board.placeElement(newTutor, nextRow, nextCol)) {
				Thread tutor = new Thread(newTutor);
				placing  = false;
				tutor.start();
			}
		}
		
		
		
	}
}
