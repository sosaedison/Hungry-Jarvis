/**
 * Directions for mobile elements on the board.
 * @author Sosa Edison-Edebor
 *
 */
public enum Direction {
	UP_LEFT, UP, UP_RIGHT, LEFT, RIGHT, DOWN_LEFT, DOWN, DOWN_RIGHT
}
